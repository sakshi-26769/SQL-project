create database Air_Cargo ;
-- 1.	Create an ER diagram for the given airlines database.

/* 2.	Write a query to create a route_details table using suitable data types for the fields, 
such as route_id, flight_num, origin_airport, destination_airport, aircraft_id, and distance_miles.
 Implement the check constraint for the flight number and unique constraint for the route_id fields. 
 Also, make sure that the distance miles field is greater than 0. */

create table  air_cargo.route_details(
route_id int primary key ,
flight_num int not null,
origin_airport varchar(10) not null,
destination_airport varchar(10) not null,
aircraft_id varchar(10) not null,
distance_miles int not null check(distance_miles >0));

desc air_cargo.route_details;
SELECT * FROM air_cargo.route_details;

use air_cargo;
SELECT * FROM air_cargo.customer;
SELECT * FROM air_cargo.passengers_on_flights;
SELECT * FROM air_cargo.ticket_details;

/* 3.	Write a query to display all the passengers (customers) who have travelled in routes 01 to 25.
 Take data from the passengers_on_flights table. */

select * from passengers_on_flights 
where route_id between 1 and 25 ;

select customer_id,route_id from passengers_on_flights
where route_id between 1 and 25
order by 1  ;

-- 4.	Write a query to identify the number of passengers and total revenue in business class from the ticket_details table.

select count(no_of_tickets) as 'no_of_passengers', sum( Price_per_ticket) as 'total rev', class_id 
from ticket_details 
where class_id = 'Bussiness';

select class_id, count(class_id) as 'number of passengers',
SUM(no_of_tickets * Price_per_ticket) AS 'total revenue'
from ticket_details
WHERE class_id = 'Bussiness' ;

-- 5.	Write a query to display the full name of the customer by extracting the first name and last name from the customer table.
select customer_id, concat(trim(first_name),' ',(last_name)) as  'full name'
from customer;

-- 6.	Write a query to extract the customers who have registered and booked a ticket. Use data from the customer and ticket_details tables.
select c.customer_id, concat(trim(first_name),' ',(last_name)) as  'full name', 
t.p_date, t.no_of_tickets from customer c inner join ticket_details t 
on c.customer_id = t.customer_id;

-- 7.	Write a query to identify the customer’s first name and last name based on their customer ID and brand (Emirates) from the ticket_details table
select c.customer_id, c.first_name, c.last_name, t.brand 
from customer c inner join ticket_details t 
on c.customer_id = t.customer_id
where t.brand = 'Emirates';

-- 8.	Write a query to identify the customers who have travelled by Economy Plus class using Group By and Having clause on the passengers_on_flights table. 
select customer_id,class_id 
from ticket_details 
group by 1,2 
having class_id = 'Economy Plus';

-- 9.	Write a query to identify whether the revenue has crossed 10000 using the IF clause on the ticket_details table.
select 
if (sum(no_of_tickets * Price_per_ticket) >  10000 ,
'rev greator than 10k',
'rev less than 10k') as 'check on revenue' 
from ticket_details;

-- 10.	Write a query to create and grant access to a new user to perform operations on a database.
drop user if exists 'junior'@'local';
create user 'junior'@'local'
identified by 'junior123';

grant all privileges on  air_cargo. * to 'junior'@'local';
select user, host from mysql.user;

-- 11.	Write a query to find the maximum ticket price for each class using window functions on the ticket_details table. 
use air_cargo ;
select *,
max(Price_per_ticket) over(partition by class_id) as 'max ticket price'
from ticket_details;

select  class_id, Price_per_ticket, brand,
MAX(Price_per_ticket) over (partition by class_id) as 'Max_ticketprice_by_ClassID'
from ticket_details
order by Price_per_ticket desc ;

-- 12.	Write a query to extract the passengers whose route ID is 4 by improving the speed and performance of the passengers_on_flights table.
select customer_id,aircraft_id,route_id from passengers_on_flights
where route_id = 4 ;

create index idx_route_id
on passengers_on_flights(route_id);

-- For the route ID 4, write a query to view the execution plan of the passengers_on_flights table.
explain select customer_id, aircraft_id, route_id
from passengers_on_flights where route_id = 4 ;

-- 14.	Write a query to calculate the total price of all tickets booked by a customer across different aircraft IDs using rollup function. 

select customer_id, aircraft_id, 
SUM(no_of_tickets * Price_per_ticket) AS 'total price'
from ticket_details
group by 1,2 WITH ROLLUP ;

-- 15.	Write a query to create a view with only business class customers along with the brand of airlines. 
create view BuisnessClass_View AS
select customer_id,class_id,brand 
from ticket_details 
where class_id = 'Bussiness';

select * from BuisnessClass_View;

/* 16.	Write a query to create a stored procedure to get the details of all passengers flying between a range of routes defined in run time.
 Also, return an error message if the table doesn't exist. */

DELIMITER //
CREATE procedure Getpassengerdetails(IN startrouteid INT, IN ENDrouteid INT)
BEGIN
	DECLARE msg varchar(255);
    -- Check if the table exists
    IF NOT EXISTS ( select * FROM information_schema.tables WHERE
    table_name = 'passengers_on_flights') then 
    set msg= 'Error: passengers_on_flights does not exist in database' ;
    SIGNAL sqlstate '45000' SET message_text = msg ;
    else 
	select customer_id, aircraft_id,route_id
	FROM passengers_on_flights 
	WHERE route_id BETWEEN startrouteid AND ENDrouteid ;
    END IF;
END //
DELIMITER ;
call Getpassengerdetails(1,10);
call Getpassengerdetails() ;

-- 17.	Write a query to create a stored procedure that extracts all the details from the routes table where the travelled distance is more than 2000 miles.
DELIMITER //
CREATE procedure GetLongroutedetails()
BEGIN
	 select * 
     from route_details
     where distance_miles > 2000 ;
END //
DELIMITER ;

/*
18.	Write a query to create a stored procedure that 
groups the distance travelled by each flight into three categories. 
The categories are, 
short distance travel (SDT) for >=0 AND <= 2000 miles, 
intermediate distance travel (IDT) for >2000 AND <=6500,
 and long-distance travel (LDT) for >6500.
*/

DELIMITER //
CREATE procedure GETdistancetravelled()
BEGIN
	select route_id, flight_num,
    CASE 
		WHEN distance_miles <= 2000 THEN 'short distance travel (SDT)'
        WHEN distance_miles <=6500 THEN 'intermediate distance travel (IDT)'
        WHEN distance_miles > 6500 THEN 'long-distance travel (LDT)'
        ELSE 'Unknown'
        end as Distance_group
   FROM route_details ;
END //
DELIMITER ;
CALL GETdistancetravelled();

/*
19.	Write a query to extract ticket purchase date, customer ID, class ID 
and specify if the complimentary services are provided for the specific class using a stored function in stored procedure on the ticket_details table. 
Condition: 
●	If the class is Business and Economy Plus, then complimentary 
services are given as Yes, else it is No
*/
DELIMITER $$

CREATE PROCEDURE GetTicketDetailsWithComplimentary()
BEGIN
    SELECT 
        p_date AS Ticket_Purchase_Date,
        customer_id,
        class_id,
        GetComplimentaryServices(class_id) AS Complimentary_Services
    FROM ticket_details;
END $$

DELIMITER ;

/*
20.	Write a query to extract the first record of the customer 
whose last name ends with Scott using a cursor from the customer table.

A **cursor** in SQL is a database object used to retrieve, manipulate, 
and iterate over rows returned by a query, one row at a time, 
for complex row-by-row operations.
*/
DELIMITER $$

CREATE PROCEDURE GetFirstCustomerWithLastNameScott()
BEGIN
    DECLARE customerID INT;
    DECLARE firstName VARCHAR(50);
    DECLARE lastName VARCHAR(50);
    DECLARE done INT DEFAULT 0;

    DECLARE cur CURSOR FOR 
    SELECT customer_id, first_name, last_name
    FROM customer
    WHERE last_name LIKE '%Scott';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    FETCH cur INTO customerID, firstName, lastName;

    IF done = 0 THEN
        SELECT customerID AS Customer_ID, firstName AS First_Name, lastName AS Last_Name;
    ELSE
        SELECT 'No customer found with last name ending in Scott' AS Message;
    END IF;

    CLOSE cur;
END $$
DELIMITER ;
 
